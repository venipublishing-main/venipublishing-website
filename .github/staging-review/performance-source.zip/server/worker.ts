import { createPerformanceOAuth, type PerformanceOAuthConfig } from './oauth.ts';

export interface Bindings {
  LOCAL_QA_COMMON_ROLE?: string;
  PERFORMANCE_ORIGIN: string;
  SUPABASE_URL: string;
  SUPABASE_PUBLISHABLE_KEY: string;
  PERFORMANCE_OAUTH_CLIENT_ID: string;
  PERFORMANCE_OAUTH_CLIENT_SECRET: string;
  PERFORMANCE_COOKIE_KEY: string;
  ASSETS: { fetch(request: Request): Promise<Response> };
}

function json(value: unknown, status: number) {
  return Response.json(value, { status, headers: { 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' } });
}

export async function handle(request: Request, env: Bindings) {
  const url = new URL(request.url);
  if (!url.pathname.startsWith('/auth/') && !url.pathname.startsWith('/api/')) return env.ASSETS.fetch(request);
  if (url.origin !== env.PERFORMANCE_ORIGIN) return json({error:'Unknown origin'},404);
  const config: PerformanceOAuthConfig = {
    localCommonRole: env.LOCAL_QA_COMMON_ROLE === 'true',
    appOrigin: env.PERFORMANCE_ORIGIN, providerOrigin: env.SUPABASE_URL,
    publishableKey: env.SUPABASE_PUBLISHABLE_KEY, clientId: env.PERFORMANCE_OAUTH_CLIENT_ID,
    clientSecret: env.PERFORMANCE_OAUTH_CLIENT_SECRET, cookieKey: env.PERFORMANCE_COOKIE_KEY,
  };
  try {
    const oauth = createPerformanceOAuth(config);
    if (url.pathname === '/auth/veni/start') return oauth.begin(request);
    if (url.pathname === '/auth/veni/callback') return oauth.callback(request);
    if (url.pathname === '/auth/local-signout') return oauth.signOut(request);
    const reading = url.pathname === '/api/workspace' && request.method === 'GET';
    const creating = url.pathname === '/api/organizations' && request.method === 'POST';
    if (!reading && !creating) return json({error:'Unknown operation'},404);
    if (creating && request.headers.get('origin') !== url.origin) return json({error:'Invalid origin'},403);
    const session = await oauth.currentSession(request);
    if (!session) return json({error:'A connected, entitled Veni Account is required'},401);
    let body: Record<string,string> = {};
    if (creating) {
      const draft = await request.json().catch(() => null);
      if (!draft || typeof draft.name !== 'string' || !['Club','Academy','School'].includes(draft.kind) ||
          draft.name.trim().length < 3 || draft.name.length > 120) return json({error:'Invalid organisation'},400);
      body = {p_name:draft.name.trim(),p_kind:draft.kind};
    }
    const name = creating ? 'performance_create_organization' : 'performance_workspace';
    const response = await fetch(config.providerOrigin+'/rest/v1/rpc/'+name,{method:'POST',redirect:'error',
      headers:{apikey:config.publishableKey,Authorization:'Bearer '+session.token,'Content-Type':'application/json'},
      signal: AbortSignal.timeout(5000),body:JSON.stringify(body)});
    if (!response.ok) return json({error:'Performance request failed'},response.status>=500?503:403);
    return json(await response.json(),creating?201:200);
  } catch {
    return json({error:'Performance connection unavailable'},503);
  }
}
export default {fetch:handle};
