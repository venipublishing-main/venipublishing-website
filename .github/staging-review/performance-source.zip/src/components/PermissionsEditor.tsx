import { useState, type FormEvent } from 'react';
import type { DemoOrganization } from '../demo/defaults';
import {
  canEditPermission, canPerform, changePermission, EDITABLE_PERMISSION_ACTIONS, permissionChoice,
  type DelegableAction, type PermissionChoice, type PermissionScope, type RoleAssignment,
} from '../domain/permissions';
import './permissions-editor.css';

interface Props {
  organization: DemoOrganization;
  onUpdate: (changes: Pick<DemoOrganization, 'permissionOverrides' | 'permissionEvents'>) => void;
  onMessage: (message: string) => void;
}

function personLabel(assignment: RoleAssignment): string {
  if (assignment.role === 'owner') return 'Organisation owner';
  if (assignment.role === 'administrator') return 'Organisation administrator';
  if (assignment.role === 'head_of_sport') return `Head of ${assignment.sportId ?? 'sport'}`;
  if (assignment.role === 'coach') return `${assignment.sportId ?? 'Sport'} · ${assignment.squadId ?? 'squad'} coach`;
  return 'Participant';
}

function staffList(organization: DemoOrganization): RoleAssignment[] {
  return organization.assignments.filter(assignment => assignment.active && assignment.role !== 'participant');
}

function scopeFor(assignment: RoleAssignment): PermissionScope {
  return { organizationId: assignment.organizationId, sportId: assignment.sportId, squadId: assignment.squadId };
}

function actionLabel(action: DelegableAction): string {
  return EDITABLE_PERMISSION_ACTIONS.find(entry => entry.action === action)?.label ?? action;
}

interface PendingChange {
  actorId: string;
  actorLabel: string;
  subjectId: string;
  subjectLabel: string;
  scope: PermissionScope;
  scopeLabel: string;
  action: DelegableAction;
  previous: PermissionChoice;
  next: PermissionChoice;
}

const CHOICE_LABELS: Record<PermissionChoice, string> = {
  inherit: 'Role default',
  allow: 'Explicitly allowed',
  deny: 'Explicitly restricted',
};

export function PermissionsEditor({ organization, onUpdate, onMessage }: Props) {
  const staff = staffList(organization);
  const [editorSuffix, setEditorSuffix] = useState('admin');
  const [subjectSuffix, setSubjectSuffix] = useState('coach-rugby');
  const [pending, setPending] = useState<PendingChange | null>(null);
  const [reason, setReason] = useState('');
  const [modalError, setModalError] = useState('');
  const editorId = `${organization.id}-${editorSuffix}`;
  const subjectId = `${organization.id}-${subjectSuffix}`;
  const editor = staff.find(assignment => assignment.userId === editorId) ?? staff[0];
  const subject = staff.find(assignment => assignment.userId === subjectId && assignment.role !== 'owner') ??
    staff.find(assignment => assignment.role === 'coach') ?? staff[1];

  if (!editor || !subject) return <section className="panel">Add active staff assignments before changing permissions.</section>;

  const scope = scopeFor(subject);
  const scopeLabel = [subject.sportId, subject.squadId].filter(Boolean).join(' / ') || 'Entire organisation';
  const recentEvents = [...organization.permissionEvents].reverse().slice(0, 6);

  function requestChoice(action: DelegableAction, next: PermissionChoice) {
    const previous = permissionChoice(organization.permissionOverrides, subject.userId, action, scope);
    if (previous === next) return;
    if (!canEditPermission(organization.assignments, organization.permissionOverrides, editor.userId, subject.userId, action, scope)) {
      onMessage('This editor is not authorised to change that permission.');
      return;
    }
    setPending({
      actorId: editor.userId, actorLabel: personLabel(editor),
      subjectId: subject.userId, subjectLabel: personLabel(subject),
      scope: { ...scope }, scopeLabel, action, previous, next,
    });
    setReason('');
    setModalError('');
  }

  function cancelChoice() {
    setPending(null);
    setReason('');
    setModalError('');
  }

  function confirmChoice(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!pending) return;
    try {
      const updated = changePermission(
        organization.assignments, organization.permissionOverrides, organization.permissionEvents,
        { actorId: pending.actorId, subjectId: pending.subjectId, scope: pending.scope,
          action: pending.action, next: pending.next, reason,
          mutationId: crypto.randomUUID(), timestamp: new Date().toISOString() },
      );
      onUpdate({ permissionOverrides: updated.overrides, permissionEvents: updated.events });
      onMessage(`${pending.subjectLabel}: ${actionLabel(pending.action)} set to ${pending.next} in ${pending.scopeLabel}. An audit entry was recorded locally.`);
      cancelChoice();
    } catch (error) {
      setModalError(error instanceof Error ? error.message : 'Unable to update this permission.');
    }
  }

  return (
    <div className="permission-editor-layout">
      <section className="panel permission-editor-main">
        <div className="panel-header">
          <div><span className="section-eyebrow">DELEGATED ROLE CONTROL</span><h2>Permission editor</h2></div>
          <span className="subtle-badge">Browser-only simulation</span>
        </div>
        <p className="muted-text">Choose a higher-tier editor and a staff member. Select a new permission to review the change, enter a reason and confirm—or cancel without changing anything.</p>
        <div className="permission-editor-selectors">
          <label>ACTING AS
            <select aria-label="Permission editor identity" value={editor.userId} onChange={event => setEditorSuffix(event.target.value.replace(`${organization.id}-`, ''))}>
              {staff.map(assignment => <option key={assignment.userId} value={assignment.userId}>{personLabel(assignment)}</option>)}
            </select>
          </label>
          <label>EDITING ACCESS FOR
            <select aria-label="Staff member whose permissions are edited" value={subject.userId} onChange={event => setSubjectSuffix(event.target.value.replace(`${organization.id}-`, ''))}>
              {staff.filter(assignment => assignment.role !== 'owner').map(assignment => <option key={assignment.userId} value={assignment.userId}>{personLabel(assignment)}</option>)}
            </select>
          </label>
        </div>
        <div className="permission-editor-scope"><span>APPLICABLE SCOPE</span><strong>{scopeLabel}</strong><small>Permissions do not extend to another sport, squad or organisation.</small></div>
        <div className="permission-editor-head"><span>CAPABILITY</span><span>EFFECTIVE ACCESS</span><span>DECISION</span></div>
        {EDITABLE_PERMISSION_ACTIONS.map(({ action, label, detail }) => {
          const value = permissionChoice(organization.permissionOverrides, subject.userId, action, scope);
          const allowed = canPerform(organization.assignments, subject.userId, action, scope, organization.permissionOverrides);
          const editable = canEditPermission(organization.assignments, organization.permissionOverrides, editor.userId, subject.userId, action, scope);
          return <div key={action} className="permission-editor-row">
            <div className="permission-action-copy"><strong>{label}</strong><small>{detail}</small></div>
            <span className={`permission-effect ${allowed ? 'effect-allowed' : 'effect-denied'}`}>{allowed ? '✓ Allowed' : '⊘ Restricted'}</span>
            <select aria-label={`Decision for ${label}`} value={value} disabled={!editable}
              title={!editable ? 'A higher-tier editor with this right is required.' : 'Select a change to review and confirm it.'}
              onChange={event => requestChoice(action, event.target.value as PermissionChoice)}>
              <option value="inherit">Role default</option>
              <option value="allow">Explicitly allow</option>
              <option value="deny">Explicitly restrict</option>
            </select>
          </div>;
        })}
        <p className="permission-boundary-note">Owners cannot be restricted here. Coaches cannot grant themselves rights. Delegation itself can be switched on for a head of sport by an administrator, and revoked later. Global organisation settings, user invitations and ownership transfer remain outside this editor.</p>
      </section>
      <section className="panel permission-audit-panel">
        <div className="panel-header"><div><span className="section-eyebrow">CHANGE HISTORY</span><h2>Authority audit</h2></div><span className="subtle-badge">{organization.permissionEvents.length} changes</span></div>
        {recentEvents.length ? <div className="permission-audit-list">
          {recentEvents.map(event => <article key={event.id}>
            <div className="permission-audit-line"><strong>{actionLabel(event.action)}</strong><span>{event.previous} → {event.next}</span></div>
            <p>{personLabel(staff.find(assignment => assignment.userId === event.subjectId) ?? subject)} · {event.scope.sportId ?? 'all sports'}{event.scope.squadId ? ` / ${event.scope.squadId}` : ''}</p>
            <small>By {personLabel(staff.find(assignment => assignment.userId === event.actorId) ?? editor)} · {new Date(event.timestamp).toLocaleString('en-ZA')}</small>
            <blockquote>{event.reason}</blockquote>
          </article>)}
        </div> : <div className="permission-empty-audit"><strong>No changes yet</strong><p>Every grant, restriction and restoration of a role default creates a separate audit event.</p></div>}
        <div className="permission-audit-tip"><strong>Try the hierarchy</strong><p>As administrator, allow the rugby coach to manage scoring. Then restrict confirmation. Switch to the rugby head: that head cannot edit coaches until an administrator grants delegation rights to the head.</p></div>
      </section>
      {pending && <div className="permission-modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) cancelChoice(); }}>
        <form className="permission-change-modal" role="dialog" aria-modal="true" aria-labelledby="permission-change-title"
          onSubmit={confirmChoice} onKeyDown={event => { if (event.key === 'Escape') { event.preventDefault(); cancelChoice(); } }}>
          <span className="section-eyebrow">REVIEW & CONFIRM</span>
          <h2 id="permission-change-title">Change staff permission?</h2>
          <p className="permission-modal-intro">Review the requested access change. It will only take effect if you confirm it.</p>
          <div className="permission-change-summary">
            <div><span>STAFF MEMBER</span><strong>{pending.subjectLabel}</strong></div>
            <div><span>CAPABILITY</span><strong>{actionLabel(pending.action)}</strong></div>
            <div><span>SCOPE</span><strong>{pending.scopeLabel}</strong></div>
            <div><span>CHANGED BY</span><strong>{pending.actorLabel}</strong></div>
          </div>
          <div className="permission-change-transition">
            <div><small>CURRENT DECISION</small><strong>{CHOICE_LABELS[pending.previous]}</strong></div>
            <span aria-hidden="true">→</span>
            <div><small>REQUESTED DECISION</small><strong>{CHOICE_LABELS[pending.next]}</strong></div>
          </div>
          <label className="permission-change-reason">REASON FOR CHANGE
            <textarea aria-label="Reason for permission change" autoFocus required minLength={3} maxLength={200} rows={3}
              value={reason} placeholder="Why is this access changing?"
              onChange={event => { setReason(event.target.value); setModalError(''); }} />
          </label>
          {modalError && <p className="permission-modal-error" role="alert">{modalError}</p>}
          <div className="permission-modal-actions">
            <button type="button" className="button-outline" onClick={cancelChoice}>Cancel</button>
            <button type="submit" className="button-primary" disabled={reason.trim().length < 3}>Apply change ✓</button>
          </div>
        </form>
      </div>}
    </div>
  );
}
