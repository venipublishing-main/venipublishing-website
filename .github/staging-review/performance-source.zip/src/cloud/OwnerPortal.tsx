import { useEffect, useState, type FormEvent } from 'react';
import { workspace, createOrganization as createRemote, type Workspace } from './client';
import { normalizeOrganizationDraft, type OrganizationKind } from './onboarding';
import './OwnerPortal.css';

export function OwnerPortal() {
  const [data,setData] = useState<Workspace|null>(null);
  const [checking,setChecking] = useState(true);
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState('');
  const [message,setMessage] = useState('');
  const [orgName,setOrgName] = useState('');
  const [kind,setKind] = useState<OrganizationKind>('Club');
  useEffect(() => {
    let active = true;
    workspace().then(result => {if (active) setData(result);})
      .catch(() => {if (active) setError('Performance workspace is unavailable.');})
      .finally(() => {if (active) setChecking(false);});
    return () => {active = false;};
  },[]);
  const user = data?.user_id;
  const entitled = Boolean(user);
  const organizations = data?.organizations ?? [];
  const roles = data?.roles ?? [];
  async function createOrganization(event:FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError(''); setMessage('');
    try {
      await createRemote(normalizeOrganizationDraft(orgName,kind));
      setMessage('Organisation created.');
      setOrgName('');
      setData(await workspace());
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Performance is unavailable.');
    } finally {setBusy(false);}
  }
  return <div className="owner-portal">
    <div className="section-eyebrow">VENI FLOW / VENI PERFORMANCE</div>
    <h1>Secure <em>organisation setup.</em></h1>
    <p className="intro-copy">Connect your Veni Account to manage your Performance organisations.</p>
    <div className="cloud-gate-banner">
      <strong>Private infrastructure pilot</strong>
      <span>Staff-invitation transactions are now secured and tested in the database, but this page offers no email delivery, public registration, real-person invitations or player enrolment. Use synthetic organisations during this pilot.</span>
    </div>
    {(message || error) && <div className={`cloud-feedback ${error ? 'is-error' : ''}`} role="status">{error || message}</div>}
    <div className="two-column">
      <section className="panel">
        <div className="section-eyebrow">01 / ACCOUNT</div>
        <h2>{checking ? 'Checking your session…' : user ? 'Connected Veni Account' : 'Veni Account sign-in'}</h2>
        {user ? <div className="cloud-account-details">
          <form method="post" action="/auth/local-signout"><button type="submit">Sign out of this browser</button></form>
          <a href="https://venipublishing.co.za/account/settings/#connected-applications">Manage connected applications</a>
        </div> : <a href="/auth/veni/start">Sign in with Veni Account</a>}
      </section>
      <section className="panel">
        <div className="section-eyebrow">02 / OWNER WORKSPACE</div>
        <h2>Create a secure organisation</h2>
        <p className="muted-text">When an entitled account creates an organisation, the database automatically assigns its creator the single owner role.</p>
        <form className="cloud-form" onSubmit={event => { void createOrganization(event); }}>
          <label>Organisation name<input required minLength={3} maxLength={120} value={orgName} onChange={event => setOrgName(event.target.value)} placeholder="e.g. Northern Hockey Club" disabled={!entitled || busy} /></label>
          <label>Organisation type<select value={kind} onChange={event => setKind(event.target.value as OrganizationKind)} disabled={!entitled || busy}><option>School</option><option>Club</option><option>Academy</option></select></label>
          <button type="submit" className="button-primary" disabled={!entitled || busy}>Create owner workspace</button>
          {!entitled && <p>Connect an entitled Veni Account to create an organisation.</p>}
        </form>
      </section>
    </div>
    <section className="panel cloud-organizations">
      <div className="section-eyebrow">03 / TENANT ISOLATION</div>
      <h2>Your accessible organisations</h2>
      {!user ? <p className="muted-text">Your own organisations appear here after sign-in. Other organisations remain hidden by database row-level security.</p>
        : organizations.length ? <div className="cloud-organization-list">{organizations.map(org => <div key={org.id} className="cloud-organization-row"><span><strong>{org.name}</strong><small>{org.kind} · Created {new Date(org.created_at).toLocaleDateString('en-ZA')}</small></span><b>{roles.some(role => role.organization_id === org.id && role.role === 'owner') ? 'Owner' : 'Member'}</b></div>)}</div>
        : <p className="muted-text">No accessible cloud organisations found. Create your first owner workspace above.</p>}
      <p className="cloud-isolation-note">These are development records. The attendance, scoring, permission and staff-invitation APIs are now secured, but the interactive sporting lab remains synthetic until controlled identity and UI integration are approved.</p>
    </section>
    <section className="panel cloud-organizations">
      <div className="section-eyebrow">04 / STAFF INVITATIONS · SECURED API</div>
      <h2>Invitation lifecycle ready for identity integration</h2>
      <p className="muted-text">Authorised owners and administrators will be able to invite sport heads and coaches into exact scopes; a delegated sport head may invite coaches only in their sport. Each invitation will be tied to the recipient's verified account, expire automatically, and retain an immutable issue/accept/revoke audit.</p>
      <p className="cloud-isolation-note">The secure database operations exist, but this page does not yet issue tokens, send emails, or enroll real people. Live registration and invitation delivery require separate safeguarding approval.</p>
    </section>
  </div>;
}
