export type OrganizationKind = 'School' | 'Club' | 'Academy';

export type OrganizationDraft = {
  name: string;
  kind: OrganizationKind;
  primary_color: string;
  secondary_color: string;
  highlight_color: string;
};

export function normalizeOrganizationDraft(name: string, kind: OrganizationKind): OrganizationDraft {
  const cleanName = name.trim().replace(/\s+/g, ' ');
  if (cleanName.length < 3 || cleanName.length > 120) {
    throw new Error('Enter an organisation name between 3 and 120 characters.');
  }
  if (!['School', 'Club', 'Academy'].includes(kind)) {
    throw new Error('Select School, Club or Academy.');
  }
  return {
    name: cleanName,
    kind,
    primary_color: '#185e43',
    secondary_color: '#af263b',
    highlight_color: '#ffffff',
  };
}
