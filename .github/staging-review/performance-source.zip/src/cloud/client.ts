import type { OrganizationDraft } from './onboarding';

export type Workspace = {
  user_id: string;
  organizations: {id:string;name:string;kind:OrganizationDraft['kind'];created_at:string}[];
  roles: {organization_id:string;role:string}[];
};

export async function workspace(): Promise<Workspace | null> {
  const response = await fetch('/api/workspace',{ cache:'no-store', credentials:'same-origin' });
  if (response.status === 401) return null;
  if (!response.ok) throw new Error('Performance workspace is unavailable.');
  return response.json();
}

export async function createOrganization(draft: OrganizationDraft): Promise<void> {
  const response = await fetch('/api/organizations', { method:'POST',credentials:'same-origin',
    headers:{'Content-Type':'application/json'},body:JSON.stringify({name:draft.name,kind:draft.kind}) });
  if (!response.ok) throw new Error('Organisation creation failed. Refresh your workspace before trying again.');
}
