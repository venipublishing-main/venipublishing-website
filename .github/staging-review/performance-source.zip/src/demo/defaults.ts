import { createAttendanceSession, type AttendanceSession } from '../domain/attendance';
import { CLUB_SAMPLE_BRANDING, normaliseBranding, PBHS_SAMPLE_BRANDING, type OrganizationBranding } from '../domain/branding';
import type { PermissionEvent, PermissionOverride, RoleAssignment } from '../domain/permissions';
import type { ScoringRule, TestDefinition } from '../domain/scoring';

export interface DemoOrganization {
  id: string;
  name: string;
  type: 'School' | 'Club' | 'Academy';
  branding: OrganizationBranding;
  rules: ScoringRule[];
  assignments: RoleAssignment[];
  permissionOverrides: PermissionOverride[];
  permissionEvents: PermissionEvent[];
  attendance: AttendanceSession;
}

export interface DemoState {
  organizations: DemoOrganization[];
  selectedOrganizationId: string;
}

export const DEMO_TESTS: TestDefinition[] = [
  {
    id: 'bench_press_1rm_bw',
    revision: 1,
    name: '1RM Bench Press',
    unit: 'x bodyweight',
    direction: 'higher',
    boundaryConvention: 'lower-inclusive',
    minimumValue: 0,
  },
  {
    id: 'shuttle_demo',
    revision: 1,
    name: 'Shuttle Time (illustrative)',
    unit: 'seconds',
    direction: 'lower',
    boundaryConvention: 'upper-inclusive',
    minimumValue: 0,
  },
];

export const DEMO_ROSTER = [
  { id: 'athlete-jordan', name: 'Jordan Lee' },
  { id: 'athlete-mia', name: 'Mia Dlamini' },
  { id: 'athlete-sam', name: 'Sam Naidoo' },
  { id: 'athlete-alex', name: 'Alex Mokoena' },
];

const PUBLISHED_AT = '2026-11-01T00:00:00.000Z';

export function makeBaseRules(organizationId: string, options?: { club?: boolean }): ScoringRule[] {
  return [
    {
      id: `${organizationId}-bench-v1`,
      testId: 'bench_press_1rm_bw',
      scope: { organizationId },
      revision: 1,
      publishedAt: PUBLISHED_AT,
      // PBHS junior reference from its 12 November 2026 strength-scoring guide.
      cutoffs: options?.club ? [0.7, 0.9, 1.1, 1.3] : [0.6, 0.8, 1.0, 1.15],
      labels: ['Poor', 'Acceptable', 'Average', 'Good', 'Excellent'],
      scores: [1, 2, 3, 4, 5],
      weight: options?.club ? 25 : 20,
    },
    {
      id: `${organizationId}-shuttle-v1`,
      testId: 'shuttle_demo',
      scope: { organizationId },
      revision: 1,
      publishedAt: PUBLISHED_AT,
      cutoffs: options?.club ? [7, 12] : [10, 13],
      labels: ['A', 'B', 'C'],
      scores: [3, 2, 1],
      weight: 15,
    },
  ];
}

export function makeAssignments(organizationId: string): RoleAssignment[] {
  return [
    { userId: `${organizationId}-owner`, organizationId, role: 'owner', active: true },
    { userId: `${organizationId}-admin`, organizationId, role: 'administrator', active: true },
    { userId: `${organizationId}-head-rugby`, organizationId, role: 'head_of_sport', sportId: 'rugby', active: true },
    { userId: `${organizationId}-coach-rugby`, organizationId, role: 'coach', sportId: 'rugby', squadId: 'rugby-a', active: true },
    { userId: `${organizationId}-head-hockey`, organizationId, role: 'head_of_sport', sportId: 'hockey', active: true },
    { userId: `${organizationId}-coach-hockey`, organizationId, role: 'coach', sportId: 'hockey', squadId: 'hockey-a', active: true },
    ...DEMO_ROSTER.map(athlete => ({ userId: athlete.id, organizationId, role: 'participant' as const, active: true })),
  ];
}

export function makeDemoOrganization(id: string, name: string, type: DemoOrganization['type'], branding: OrganizationBranding, club = false): DemoOrganization {
  return {
    id, name, type, branding: normaliseBranding(branding),
    rules: makeBaseRules(id, { club }),
    assignments: makeAssignments(id),
    permissionOverrides: [],
    permissionEvents: [],
    attendance: createAttendanceSession({
      id: `${id}-attendance-1`,
      organizationId: id,
      sportId: 'rugby',
      squadId: 'rugby-a',
      scheduledAt: '2026-11-13T14:00:00.000Z',
      roster: DEMO_ROSTER.map(athlete => athlete.id),
    }),
  };
}

export function initialDemoState(): DemoState {
  return {
    organizations: [
      makeDemoOrganization('pbhs', 'Pretoria Boys High School', 'School', PBHS_SAMPLE_BRANDING),
      makeDemoOrganization('club-example', 'Example Athletics Club', 'Club', CLUB_SAMPLE_BRANDING, true),
    ],
    selectedOrganizationId: 'pbhs',
  };
}

/** Convert saved v0.1 browser demo state without dropping user-created organisation settings. */
export function recoverDemoState(value: unknown): DemoState | null {
  if (!value || typeof value !== 'object') return null;
  const saved = value as Partial<DemoState>;
  if (!Array.isArray(saved.organizations) || !saved.organizations.length || typeof saved.selectedOrganizationId !== 'string') return null;
  const organizations = saved.organizations.map(organization => {
    if (!organization || typeof organization.id !== 'string' || !Array.isArray(organization.rules) || !organization.attendance) return null;
    const legacyAccent = (organization as DemoOrganization & { accent?: string }).accent;
    const fallback = organization.id === 'pbhs' ? PBHS_SAMPLE_BRANDING : { ...CLUB_SAMPLE_BRANDING, ...(legacyAccent && { primary: legacyAccent }) };
    const assignments = Array.isArray(organization.assignments) ? [...organization.assignments] : makeAssignments(organization.id);
    if (!assignments.some(assignment => assignment.role === 'administrator' && assignment.organizationId === organization.id)) {
      assignments.push({ userId: `${organization.id}-admin`, organizationId: organization.id, role: 'administrator', active: true });
    }
    return {
      ...organization,
      branding: normaliseBranding(organization.branding, fallback),
      assignments,
      permissionOverrides: Array.isArray(organization.permissionOverrides) ? organization.permissionOverrides : [],
      permissionEvents: Array.isArray(organization.permissionEvents) ? organization.permissionEvents : [],
    };
  });
  if (organizations.includes(null)) return null;
  const typed = organizations as DemoOrganization[];
  return {
    organizations: typed,
    selectedOrganizationId: typed.some(org => org.id === saved.selectedOrganizationId) ? saved.selectedOrganizationId : typed[0].id,
  };
}
