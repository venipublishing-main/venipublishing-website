import { useEffect, useState, type CSSProperties, type FormEvent } from 'react';
import { createAttendanceSession, confirmAttendance, recordAttendance, type AttendanceStatus } from './domain/attendance';
import { OwnerPortal } from './cloud/OwnerPortal';
import { PermissionsEditor } from './components/PermissionsEditor';
import { brandInkOnWhite, CLUB_SAMPLE_BRANDING, PBHS_SAMPLE_BRANDING, prepareBadgePreview, textOnColour, type OrganizationBranding } from './domain/branding';
import { canPerform } from './domain/permissions';
import { publishRuleRevision, resolveScoringRule, scoreMeasurement, strengthRatio } from './domain/scoring';
import { DEMO_ROSTER, DEMO_TESTS, initialDemoState, makeDemoOrganization, recoverDemoState, type DemoOrganization, type DemoState } from './demo/defaults';

type Page = 'overview' | 'access' | 'branding' | 'scoring' | 'people' | 'attendance';
const PAGE_LABELS: Record<Page, string> = { overview: 'Overview', access: 'Secure owner setup', branding: 'Organisation setup', scoring: 'Scoring studio', people: 'People & authority', attendance: 'Attendance' };
const STORAGE_KEY = 'sports-platform-foundation-demo-v1';

function loadDemo(): DemoState {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const recovered = recoverDemoState(JSON.parse(saved));
      if (recovered) return recovered;
    }
  } catch { /* Inaccessible or stale browser storage starts a clean synthetic demo. */ }
  return initialDemoState();
}

function formatCutoff(value: number, testId: string): string {
  return testId === 'bench_press_1rm_bw' ? `${Math.round(value * 100)}% BW` : `${value} s`;
}

function formatMeasurement(value: number, testId: string): string {
  return testId === 'bench_press_1rm_bw' ? `${(value * 100).toFixed(1)}% BW` : `${value.toFixed(2)} s`;
}

function NavigationIcon({ page }: { page: Page }) {
  return <span className="nav-icon" aria-hidden="true">{{ overview: '◈', access: '♙', branding: '✧', scoring: '▥', people: '♟', attendance: '✓' }[page]}</span>;
}

function BrandBadge({ branding, name, size = 'normal' }: { branding: OrganizationBranding; name: string; size?: 'small' | 'normal' | 'large' }) {
  const initials = name.split(/\s+/).filter(Boolean).slice(0, 3).map(word => word[0].toUpperCase()).join('');
  return <span className={`brand-badge brand-badge-${size}`} aria-label={branding.badgeDataUrl ? `${name} badge` : `${name} monogram`}>
    {branding.badgeDataUrl ? <img src={branding.badgeDataUrl} alt="" /> : <span className="badge-monogram">{initials}</span>}
  </span>;
}

export default function App() {
  const [state, setState] = useState<DemoState>(loadDemo);
  const [page, setPage] = useState<Page>(() => typeof window !== 'undefined' && window.location.pathname === '/owner' ? 'access' : 'overview');
  const [testId, setTestId] = useState('shuttle_demo');
  const [rawValue, setRawValue] = useState('8');
  const [draftCutoffs, setDraftCutoffs] = useState<string[]>([]);
  const [draftWeight, setDraftWeight] = useState('');
  const [newOrgName, setNewOrgName] = useState('');
  const [newOrgType, setNewOrgType] = useState<DemoOrganization['type']>('Club');
  const [newBranding, setNewBranding] = useState<OrganizationBranding>({ ...CLUB_SAMPLE_BRANDING });
  const [showCreate, setShowCreate] = useState(false);
  const [brandActor, setBrandActor] = useState<'owner' | 'admin' | 'head' | 'coach'>('owner');
  const [scoringActor, setScoringActor] = useState<'owner' | 'admin' | 'head' | 'coach'>('owner');
  const [badgeUploading, setBadgeUploading] = useState(false);
  const [selectedActor, setSelectedActor] = useState('coach');
  const [correctionNote, setCorrectionNote] = useState('');
  const [message, setMessage] = useState('');

  const organization = state.organizations.find(org => org.id === state.selectedOrganizationId) ?? state.organizations[0];
  const definition = DEMO_TESTS.find(test => test.id === testId)!;
  const rule = resolveScoringRule(organization.rules, { organizationId: organization.id, testId })!;
  const brand = organization.branding;
  const accentStyle = {
    '--org-primary': brand.primary,
    '--org-on-primary': textOnColour(brand.primary),
    '--org-secondary': brand.secondary,
    '--org-on-secondary': textOnColour(brand.secondary),
    '--org-highlight': brand.highlight,
    '--org-accent': brandInkOnWhite(brand.primary),
  } as CSSProperties;

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
    catch { /* Browsers that disable storage can still use the lab for the current visit. */ }
  }, [state]);
  useEffect(() => {
    setDraftCutoffs(rule.cutoffs.map(String));
    setDraftWeight(String(rule.weight));
  }, [organization.id, rule.id]);

  function updateOrganization(updater: (org: DemoOrganization) => DemoOrganization) {
    setState(previous => ({
      ...previous,
      organizations: previous.organizations.map(org => org.id === organization.id ? updater(org) : org),
    }));
  }

  function selectOrganization(id: string) {
    setState(previous => ({ ...previous, selectedOrganizationId: id }));
    setMessage('');
  }

  function createOrganization(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const name = newOrgName.trim();
    if (name.length < 3) { setMessage('Enter an organisation name of at least three characters.'); return; }
    const id = `org-${crypto.randomUUID().slice(0, 8)}`;
    const org = makeDemoOrganization(id, name, newOrgType, newBranding);
    setState(previous => ({ organizations: [...previous.organizations, org], selectedOrganizationId: id }));
    setNewOrgName('');
    setNewBranding({ ...CLUB_SAMPLE_BRANDING });
    setShowCreate(false);
    setPage('branding');
    setBrandActor('owner');
    setMessage(`${name} created as a separate local workspace. You can upload its badge and customise its appearance here.`);
  }

  const brandActorId = brandActor === 'owner' ? `${organization.id}-owner`
    : brandActor === 'admin' ? `${organization.id}-admin`
    : brandActor === 'head' ? `${organization.id}-head-rugby`
    : `${organization.id}-coach-rugby`;
  const canManageBrand = canPerform(organization.assignments, brandActorId, 'manage_organization', { organizationId: organization.id }, organization.permissionOverrides);

  function changeBrandColour(field: 'primary' | 'secondary' | 'highlight', value: string) {
    if (!canManageBrand) { setMessage('Only the organisation owner or an administrator can edit branding.'); return; }
    updateOrganization(org => ({ ...org, branding: { ...org.branding, [field]: value } }));
  }

  async function uploadBadge(file: File | undefined) {
    if (!file) return;
    if (!canManageBrand) { setMessage('Only an organisation owner or administrator can upload its badge.'); return; }
    setBadgeUploading(true);
    try {
      const badgeDataUrl = await prepareBadgePreview(file);
      updateOrganization(org => ({ ...org, branding: { ...org.branding, badgeDataUrl } }));
      setMessage('Badge uploaded and resized locally. It is visible only in this browser until cloud storage is connected.');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Could not prepare this badge.'); }
    finally { setBadgeUploading(false); }
  }

  function removeBadge() {
    if (!canManageBrand) return;
    updateOrganization(org => ({ ...org, branding: { ...org.branding, badgeDataUrl: undefined } }));
    setMessage('Custom badge removed. The organisation monogram is shown instead.');
  }

  function resetBranding() {
    if (!canManageBrand) return;
    updateOrganization(org => ({ ...org, branding: { ...org.branding, ...(org.id === 'pbhs' ? PBHS_SAMPLE_BRANDING : CLUB_SAMPLE_BRANDING) } }));
    setMessage('Sample colours restored for this organisation. Its uploaded badge was retained.');
  }

  function saveScoringRule() {
    try {
      const scoringActorId = `${organization.id}-${scoringActor === 'head' ? 'head-rugby' : scoringActor === 'coach' ? 'coach-rugby' : scoringActor}`;
      if (!canPerform(organization.assignments, scoringActorId, 'manage_scoring', { organizationId: organization.id }, organization.permissionOverrides)) {
        throw new Error('This actor cannot publish an organisation-wide scoring rule. A squad-scoped grant does not allow changing global defaults.');
      }
      const cutoffs = draftCutoffs.map(Number);
      if (draftCutoffs.some(value => value.trim() === '')) throw new Error('Every cutoff needs a value.');
      if (draftWeight.trim() === '') throw new Error('Enter a test weight.');
      const publicationTime = new Date(Math.max(Date.now(), Date.parse(rule.publishedAt) + 1)).toISOString();
      const next = publishRuleRevision(rule, {
        cutoffs, labels: rule.labels, scores: rule.scores, weight: Number(draftWeight),
      }, publicationTime, `${organization.id}-${testId}-${crypto.randomUUID().slice(0, 8)}`);
      updateOrganization(org => ({ ...org, rules: [...org.rules, next] }));
      setMessage(`Published revision ${next.revision} for ${organization.name}. Previous scoring revisions were retained.`);
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Could not save scoring rules.'); }
  }

  const numericRaw = Number(rawValue);
  let result = null;
  let resultError = '';
  try {
    if (rawValue.trim() === '') throw new Error('Enter a result to preview its score.');
    result = scoreMeasurement(definition, rule, numericRaw);
  } catch (error) { resultError = error instanceof Error ? error.message : 'Invalid measurement'; }

  const attendance = organization.attendance;
  const currentActorId = selectedActor === 'owner' ? `${organization.id}-owner`
    : selectedActor === 'admin' ? `${organization.id}-admin`
    : selectedActor === 'head' ? `${organization.id}-head-rugby`
    : `${organization.id}-coach-rugby`;

  function changeAttendance(participantId: string, status: AttendanceStatus, participantCheckIn = false) {
    try {
      const next = recordAttendance(attendance, organization.assignments, {
        actorId: participantCheckIn ? participantId : currentActorId,
        participantId,
        status,
        source: participantCheckIn ? 'participant_check_in' : attendance.state === 'confirmed' ? 'coach_correction' : 'coach_entry',
        timestamp: new Date().toISOString(),
        mutationId: crypto.randomUUID(),
        note: attendance.state === 'confirmed' ? correctionNote.trim() : undefined,
      }, organization.permissionOverrides);
      updateOrganization(org => ({ ...org, attendance: next }));
      setMessage(attendance.state === 'confirmed' ? 'Coach correction recorded, with an audit event.' : 'Attendance updated. Coach confirmation is still required.');
      if (attendance.state === 'confirmed') setCorrectionNote('');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Unable to record attendance.'); }
  }

  function confirmSession() {
    try {
      const next = confirmAttendance(attendance, organization.assignments, currentActorId, crypto.randomUUID(), new Date().toISOString(), organization.permissionOverrides);
      updateOrganization(org => ({ ...org, attendance: next }));
      setMessage('Session confirmed by the authorised staff member. Further corrections require a reason.');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Unable to confirm session.'); }
  }

  function resetAttendance() {
    updateOrganization(org => ({
      ...org,
      attendance: createAttendanceSession({
        id: crypto.randomUUID(), organizationId: org.id, sportId: 'rugby', squadId: 'rugby-a',
        scheduledAt: new Date().toISOString(), roster: DEMO_ROSTER.map(athlete => athlete.id),
      }),
    }));
    setMessage('A fresh synthetic attendance session is open.');
  }

  const completedAttendance = Object.keys(attendance.entries).length;
  const latestEvent = attendance.events[attendance.events.length - 1];

  return (
    <div className="app-shell" style={accentStyle}>
      <aside className="sidebar">
        <div className="brand-lockup"><span className="brand-mark">◈</span><span><strong>VENI FLOW</strong><small>PERFORMANCE LAB</small></span></div>
        <div className="workspace-label">WORKSPACE</div>
        <div className="workspace-picker">
          <BrandBadge branding={brand} name={organization.name} size="small" />
          <select aria-label="Select organisation" value={organization.id} onChange={event => selectOrganization(event.target.value)}>
            {state.organizations.map(org => <option key={org.id} value={org.id}>{org.name}</option>)}
          </select>
        </div>
        <button className="new-workspace" onClick={() => setShowCreate(true)}>＋ New organisation</button>
        <div className="nav-label">PLATFORM</div>
        <nav className="primary-nav" aria-label="Main navigation">
          {(['overview', 'access', 'branding', 'scoring', 'people', 'attendance'] as Page[]).map(item => (
            <button key={item} className={`nav-button ${page === item ? 'active' : ''}`} onClick={() => { setPage(item); setMessage(''); }}>
              <NavigationIcon page={item} /> {PAGE_LABELS[item]}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom"><span className="status-pulse" /> Shared engine <span>·</span> independent settings<br /><small>A Veni Flow product · private foundation v0.5.1</small></div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumbs">Veni Flow <span>/</span> Performance <span>/</span> {organization.name} <span>/</span> <strong>{PAGE_LABELS[page]}</strong></div>
          <div className="topbar-right"><BrandBadge branding={brand} name={organization.name} size="small" /><span className="prototype-pill">SYNTHETIC DATA</span><span className="avatar">OV</span></div>
        </header>
        <div className="content-wrap">
          {message && <div className="notice" role="status"><span>ⓘ</span> {message}<button aria-label="Dismiss message" onClick={() => setMessage('')}>×</button></div>}

          {page === 'overview' && <>
            <div className="section-eyebrow">VENI FLOW / PERFORMANCE FOUNDATION</div>
            <h1>One platform.<br /><em>Every team, their way.</em></h1>
            <p className="intro-copy">The calculation engine stays consistent. Organisations manage their own scoring boundaries, sports, people and attendance approvals.</p>
            <div className="organisation-identity-strip">
              <BrandBadge branding={brand} name={organization.name} size="large" />
              <div className="organisation-identity-copy"><span>ACTIVE ORGANISATION</span><strong>{organization.name}</strong><small>{organization.type} workspace · independently configured</small></div>
              <div className="organisation-identity-colours" aria-label="Organisation colour palette"><span style={{ background: brand.secondary }} /><span style={{ background: brand.highlight }} /><span style={{ background: brand.primary }} /></div>
              <button className="identity-edit" onClick={() => setPage('branding')}>Customise identity ↗</button>
            </div>
            <div className="stat-grid">
              <div className="stat-card"><span>ORGANISATIONS</span><strong>{state.organizations.length.toString().padStart(2, '0')}</strong><small>Independent workspaces</small></div>
              <div className="stat-card"><span>CORE TESTS</span><strong>{DEMO_TESTS.length.toString().padStart(2, '0')}</strong><small>Same test definitions</small></div>
              <div className="stat-card"><span>SCORING RULES</span><strong>{organization.rules.length.toString().padStart(2, '0')}</strong><small>Includes saved revisions</small></div>
              <div className="stat-card"><span>ATTENDANCE</span><strong>{attendance.state === 'confirmed' ? '✓' : 'OPEN'}</strong><small>{completedAttendance}/{attendance.roster.length} marked</small></div>
            </div>
            <div className="two-column">
              <section className="panel feature-panel"><span className="section-eyebrow">SHARED METHOD</span><h2>One formula, many interpretations.</h2><p>A raw result of <strong>8.00 seconds</strong> can receive a different classification in each organisation while the underlying measurement stays exactly the same.</p><button className="button-primary" onClick={() => { setTestId('shuttle_demo'); setRawValue('8'); setPage('scoring'); }}>Explore scoring <span>↗</span></button></section>
              <section className="panel"><span className="section-eyebrow">OPERATING MODEL</span><h2>Designed for self-service</h2><div className="steps"><div><b>01</b><span>Create an organisation</span></div><div><b>02</b><span>Adjust rules and weightings</span></div><div><b>03</b><span>Assign sport and squad authority</span></div><div><b>04</b><span>Collect and confirm attendance</span></div></div><button className="text-link" onClick={() => setPage('access')}>View secure owner setup ↗</button></section>
            </div>
            <div className="prototype-footnote">This is a private configuration prototype. Badges, settings and synthetic participants save only in this browser; real signup, QR invitations, cloud persistence and cross-device sync are subsequent integrations.</div>
          </>}

          {page === 'access' && <OwnerPortal />}

          {page === 'branding' && <>
            <div className="section-eyebrow">SELF-SERVICE ORGANISATION SETUP</div><h1>Make it <em>yours.</em></h1>
            <p className="intro-copy">Every school or club owns its visual identity. These choices change its workspace without changing the shared calculations or any other organisation.</p>
            <div className="brand-preview-panel" style={{ background: 'var(--org-primary)', color: 'var(--org-on-primary)' }}>
              <div className="brand-preview-band"><span style={{ background: brand.secondary }} /><span style={{ background: brand.highlight }} /><span style={{ background: brand.primary }} /></div>
              <div className="brand-preview-content"><BrandBadge branding={brand} name={organization.name} size="large" /><div><span className="preview-eyebrow">ORGANISATION PREVIEW</span><h2>{organization.name}</h2><p>{organization.type} · Powered by Veni Performance, part of Veni Flow</p></div></div>
              <div className="brand-preview-corner">01 / VISUAL IDENTITY</div>
            </div>
            <div className="two-column brand-editor-layout">
              <section className="panel"><div className="panel-header"><div><span className="section-eyebrow">COLOUR SYSTEM</span><h2>Club palette</h2></div><span className="subtle-badge">Live preview</span></div>
                <p className="muted-text">Choose three brand colours. Text and controls adapt to keep the interface readable.</p>
                {([['primary', 'Primary / main colour'], ['secondary', 'Secondary / action colour'], ['highlight', 'Third / stripe colour']] as const).map(([field, label]) => <label className="brand-colour-row" key={field}><span><strong>{label}</strong><small>{brand[field].toUpperCase()}</small></span><input type="color" aria-label={label} value={brand[field]} disabled={!canManageBrand} onChange={event => changeBrandColour(field, event.target.value)} /></label>)}
                <div className="brand-sample-palette"><span style={{ background: brand.secondary }} /><span style={{ background: brand.highlight }} /><span style={{ background: brand.primary }} /></div>
                <button className="button-outline reset-brand" disabled={!canManageBrand} onClick={resetBranding}>Restore sample palette</button>
              </section>
              <section className="panel"><div className="panel-header"><div><span className="section-eyebrow">CLUB BADGE</span><h2>Emblem / logo</h2></div><span className="subtle-badge">Your asset</span></div>
                <div className="badge-upload-preview"><BrandBadge branding={brand} name={organization.name} size="large" /><div><strong>{brand.badgeDataUrl ? 'Custom badge applied' : 'Monogram placeholder'}</strong><small>{brand.badgeDataUrl ? 'Visible on this organisation’s pages' : 'Upload the official school crest or club logo whenever you’re ready.'}</small></div></div>
                <label className={`upload-badge-button ${!canManageBrand ? 'is-disabled' : ''}`}><input aria-label="Upload organisation badge" type="file" accept="image/png,image/jpeg,image/webp" disabled={!canManageBrand || badgeUploading} onChange={event => { void uploadBadge(event.target.files?.[0]); event.target.value = ''; }} /><span>{badgeUploading ? 'Preparing badge…' : '↑ Upload PNG, JPG or WebP'}</span></label>
                <p className="muted-text upload-note">Images are resized in your browser. SVG is disabled for safety. In production, approved assets will be stored securely for the organisation.</p>
                {brand.badgeDataUrl && <button className="text-link" onClick={removeBadge} disabled={!canManageBrand}>Remove custom badge</button>}
              </section>
            </div>
            <div className="panel brand-authority-note"><div><span className="section-eyebrow">BRANDING AUTHORITY</span><h2>Who can change the identity?</h2><p className="muted-text">The owner or an administrator controls branding. Sport heads and coaches cannot alter the whole organisation’s appearance.</p></div><label className="compact-actor">PREVIEW ACCESS AS<select value={brandActor} onChange={event => setBrandActor(event.target.value as typeof brandActor)}><option value="owner">Organisation owner</option><option value="admin">Administrator</option><option value="head">Head of rugby</option><option value="coach">Rugby coach</option></select></label><span className={`authority-indicator ${canManageBrand ? 'authority-allowed' : 'authority-denied'}`}>{canManageBrand ? '✓ Can edit' : 'Locked for this role'}</span></div>
            <div className="prototype-footnote">Branding is currently saved per workspace in this browser only. A production owner account, cloud badge storage, and secure organisation onboarding are the next backend milestone. The example PBHS colours are illustrative, not claimed as official hex codes.</div>
          </>}

          {page === 'scoring' && <>
            <div className="section-eyebrow">RULE CONFIGURATION</div><h1>Scoring <em>studio.</em></h1><p className="intro-copy">Keep the test method fixed while each organisation publishes its own thresholds and weightings.</p>
            <div className="panel controls-row">
              <label>TEST DEFINITION<select value={testId} onChange={event => { setTestId(event.target.value); setRawValue(event.target.value === 'shuttle_demo' ? '8' : '1.15'); }}>{DEMO_TESTS.map(test => <option key={test.id} value={test.id}>{test.name}</option>)}</select></label>
              <label>ACTIVE RULE SCOPE<div className="input-static">Organisation default</div></label>
              <label>RULE VERSION<div className="input-static">Revision {rule.revision}</div></label>
            </div>
            <div className="two-column scoring-layout">
              <section className="panel"><div className="panel-header"><div><span className="section-eyebrow">CUSTOMER SETTINGS</span><h2>Thresholds & weight</h2></div><span className="subtle-badge">Editable</span></div>
                <p className="muted-text">These values belong to <strong>{organization.name}</strong>. The underlying test definition stays shared.</p>
                <div className="band-editor">
                  {rule.labels.map((label, index) => <div key={`${label}-${index}`} className="band-row"><span className="band-color" style={{ opacity: 0.35 + index * (0.55 / rule.labels.length) }} /><span className="band-name">{label}</span><span className="band-range">{index === 0 ? 'up to boundary' : index === rule.labels.length - 1 ? 'from previous boundary' : 'to next boundary'}</span>{index < rule.cutoffs.length ? <input aria-label={`${label} cutoff`} type="number" step="0.01" value={draftCutoffs[index] ?? ''} onChange={event => setDraftCutoffs(previous => previous.map((cutoff, cutoffIndex) => cutoffIndex === index ? event.target.value : cutoff))} /> : <span className="last-band">Final band</span>}</div>)}
                </div>
                <div className="weight-field"><label>TEST WEIGHT<input aria-label="Test weight" type="number" min="0" step="1" value={draftWeight} onChange={event => setDraftWeight(event.target.value)} /></label><small>Used by the shared weighted-summary method. Summary parity with the PBHS workbook is still to be audited.</small></div>
                <label className="compact-actor">PUBLISH ORGANISATION DEFAULT AS<select value={scoringActor} onChange={event => setScoringActor(event.target.value as typeof scoringActor)}><option value="owner">Organisation owner</option><option value="admin">Administrator</option><option value="head">Head of rugby</option><option value="coach">Rugby coach</option></select></label>
                <p className="muted-text">This editor publishes global defaults. Sport or squad scoring permissions do not authorise changing every team's thresholds.</p>
                <button className="button-primary full-width" onClick={saveScoringRule}>Publish organisation revision <span>↗</span></button>
              </section>
              <section className="panel"><div className="panel-header"><div><span className="section-eyebrow">LIVE EVALUATION</span><h2>Result preview</h2></div><span className="subtle-badge">Same core</span></div>
                <label className="value-label">RECORDED MEASUREMENT<input type="number" step="0.01" value={rawValue} onChange={event => setRawValue(event.target.value)} /></label>
                <div className="result-display"><span>CLASSIFICATION</span><strong>{result?.label ?? '—'}</strong><small>{result ? `${formatMeasurement(result.rawValue, testId)} · score ${result.score}` : resultError}</small></div>
                <div className="definition-note"><b>Fixed definition</b><span>{definition.name} · {definition.unit} · {definition.direction} is better</span></div>
                <div className="definition-note"><b>Boundary rule</b><span>Exact thresholds belong to the {definition.boundaryConvention === 'upper-inclusive' ? 'lower-result' : 'higher-result'} band.</span></div>
                <div className="definition-note"><b>Published cutoffs</b><span>{rule.cutoffs.map(value => formatCutoff(value, testId)).join('  ·  ')}</span></div>
                <div className="definition-note"><b>History reference</b><span>Test method v{definition.revision} · rule {rule.id} v{rule.revision}</span></div>
                {testId === 'bench_press_1rm_bw' && <button className="text-link" onClick={() => setRawValue(String(strengthRatio(75, 60)))}>Use example: 75 kg ÷ 60 kg = 1.25 →</button>}
              </section>
            </div>
            <div className="prototype-footnote">The initial lab implements organisation-wide published rules. The core already supports sport and division scope, ready for the next configuration-design decision.</div>
          </>}

          {page === 'people' && <>
            <div className="section-eyebrow">AUTHORITY & IDENTITY</div><h1>People & <em>permissions.</em></h1><p className="intro-copy">Owners, administrators and delegated sport heads can fine-tune coach capabilities within their authority. Every grant, restriction and restoration is recorded.</p>
            <div className="two-column">
              <section className="panel"><span className="section-eyebrow">DEMONSTRATION STRUCTURE</span><h2>{organization.name}</h2><div className="authority-tree"><div className="tree-owner">◈ Organisation owner</div><div className="tree-branch"><div className="tree-head">↳ Organisation administrator</div><div className="tree-head">↳ Head of Rugby</div><div className="tree-coach">↳ Rugby Squad A · Coach</div><div className="tree-head">↳ Head of Hockey</div><div className="tree-coach">↳ Hockey Squad A · Coach</div></div></div><div className="definition-note"><b>Access principle</b><span>Roles are scoped to an organisation, sport or squad. A person may have multiple assignments, without self-escalation.</span></div></section>
              <section className="panel"><span className="section-eyebrow">EFFECTIVE PERMISSIONS</span><h2>Try a role</h2><label className="value-label">ACTOR<select value={selectedActor} onChange={event => setSelectedActor(event.target.value)}><option value="owner">Organisation owner</option><option value="admin">Administrator</option><option value="head">Head of rugby</option><option value="coach">Rugby coach</option></select></label><div className="permission-list">{(['manage_organization', 'manage_permissions', 'manage_scoring', 'manage_attendance', 'confirm_attendance'] as const).map(action => <div key={action}><span>{action.replaceAll('_', ' ')}</span><b className={canPerform(organization.assignments, currentActorId, action, { organizationId: organization.id, sportId: 'rugby', squadId: 'rugby-a' }, organization.permissionOverrides) ? 'allowed' : 'denied'}>{canPerform(organization.assignments, currentActorId, action, { organizationId: organization.id, sportId: 'rugby', squadId: 'rugby-a' }, organization.permissionOverrides) ? 'Allowed' : 'Restricted'}</b></div>)}</div></section>
            </div>
            <PermissionsEditor key={organization.id} organization={organization} onUpdate={changes => updateOrganization(org => ({ ...org, ...changes }))} onMessage={setMessage} />
            <section className="panel full-panel"><div className="panel-header"><div><span className="section-eyebrow">PERSON-FIRST ENROLMENT</span><h2>Permanent profile → squad membership</h2></div><span className="subtle-badge">Design contract</span></div><p className="muted-text">A squad QR invitation will link an existing or newly created profile to the correct organisation and squad. Attendance check-ins use separate, session-specific codes. The secure invitation and identity services are next-stage backend work.</p><div className="identity-steps"><span>Profile ID</span><span>→</span><span>Organisation membership</span><span>→</span><span>Sport & squad assignment</span><span>→</span><span>Seasons and results</span></div></section>
          </>}

          {page === 'attendance' && <>
            <div className="section-eyebrow">COACH APPROVAL WORKFLOW</div><h1>Attendance <em>control.</em></h1><p className="intro-copy">Participant check-ins remain provisional. An authorised coach reviews every roster member and confirms the session, with corrections recorded afterwards.</p>
            <div className="panel attendance-head"><div><span className="section-eyebrow">SYNTHETIC RUGBY SESSION</span><h2>Squad A · Training attendance</h2><p>{completedAttendance} of {attendance.roster.length} marked · {attendance.events.length} audit events</p></div><div className="attendance-actions"><span className={`status-badge ${attendance.state}`}>{attendance.state === 'confirmed' ? '✓ Confirmed' : '● Awaiting confirmation'}</span><button className="button-outline" onClick={resetAttendance}>New test session</button></div></div>
            <div className="panel attendance-panel"><div className="panel-header"><div><span className="section-eyebrow">ROSTER REVIEW</span><h2>Record & confirm</h2></div><label className="compact-actor">OPERATING AS<select value={selectedActor} onChange={event => setSelectedActor(event.target.value)}><option value="coach">Rugby coach</option><option value="head">Head of rugby</option><option value="admin">Administrator</option><option value="owner">Organisation owner</option></select></label></div>
              {attendance.state === 'confirmed' && <label className="correction-reason">CORRECTION REASON<input placeholder="Required for post-confirmation changes" value={correctionNote} onChange={event => setCorrectionNote(event.target.value)} /></label>}
              <div className="roster-list">{DEMO_ROSTER.map(person => { const entry = attendance.entries[person.id]; return <div className="roster-row" key={person.id}><div className="person-initials">{person.name.split(' ').map(part => part[0]).join('')}</div><div className="person-name"><strong>{person.name}</strong><small>{entry ? `${entry.source.replaceAll('_', ' ')} · ${entry.changedBy === person.id ? 'participant' : 'staff'}` : 'Unmarked'}</small></div><span className={`att-status ${entry?.status ?? 'unmarked'}`}>{entry?.status ?? 'Unmarked'}</span><div className="roster-controls">{!entry && attendance.state === 'open' && <button className="checkin-btn" onClick={() => changeAttendance(person.id, 'present', true)}>Self check-in</button>}<select aria-label={`Set attendance for ${person.name}`} value={entry?.status ?? ''} onChange={event => changeAttendance(person.id, event.target.value as AttendanceStatus)}><option value="" disabled>Coach mark…</option><option value="present">Present</option><option value="absent">Absent</option><option value="late">Late</option><option value="excused">Excused</option></select></div></div>; })}</div>
              <div className="confirmation-footer"><div><strong>{attendance.state === 'confirmed' ? 'Session confirmed' : `${attendance.roster.length - completedAttendance} statuses remaining`}</strong><small>{attendance.state === 'confirmed' ? `Confirmed by ${attendance.confirmedBy}${attendance.amendedAt ? ' · amended with audit trail' : ''}` : 'Every roster member must have a status before coach confirmation.'}</small></div><button className="button-primary" onClick={confirmSession} disabled={attendance.state === 'confirmed'}>{attendance.state === 'confirmed' ? 'Confirmed ✓' : 'Confirm entire session'}</button></div>
            </div>
            <div className="two-column"><section className="panel"><span className="section-eyebrow">LATEST AUDIT EVENT</span><h2>{latestEvent ? latestEvent.kind.replaceAll('_', ' ') : 'No changes yet'}</h2><p className="muted-text">{latestEvent ? `${latestEvent.actorId} · ${new Date(latestEvent.timestamp).toLocaleString('en-ZA')}` : 'Check in a participant or have a coach enter attendance to create a traceable event.'}</p>{latestEvent?.note && <p className="muted-text">Reason: {latestEvent.note}</p>}</section><section className="panel"><span className="section-eyebrow">OFFLINE CONTRACT</span><h2>Safe queued mutations</h2><p className="muted-text">Every attendance action carries a unique mutation ID so retrying after lost connectivity can be handled without repeating the same event. Device storage and live synchronisation will be added with the backend.</p></section></div>
          </>}
        </div>
      </main>

      {showCreate && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) setShowCreate(false); }}>
        <form className="modal-card" onSubmit={createOrganization}>
          <div className="section-eyebrow">SELF-SERVICE ONBOARDING / STEP 01</div><h2>Create an organisation</h2>
          <p>Choose a name and colours. We’ll create a separate local workspace, then take you to its badge and branding setup.</p>
          <label>ORGANISATION NAME<input autoFocus required minLength={3} value={newOrgName} onChange={event => setNewOrgName(event.target.value)} placeholder="e.g. Northside Sports Club" /></label>
          <label>ORGANISATION TYPE<select value={newOrgType} onChange={event => setNewOrgType(event.target.value as DemoOrganization['type'])}><option>School</option><option>Club</option><option>Academy</option></select></label>
          <div className="new-org-branding-heading">STARTER COLOURS <span>Change these later if you prefer</span></div>
          <div className="new-org-colours">{([['primary', 'Primary'], ['secondary', 'Secondary'], ['highlight', 'Third']] as const).map(([field, label]) => <label key={field}>{label}<input type="color" value={newBranding[field]} onChange={event => setNewBranding(previous => ({ ...previous, [field]: event.target.value }))} /></label>)}</div>
          <div className="new-org-preview" style={{ background: newBranding.primary, color: textOnColour(newBranding.primary) }}><span>{newOrgName.trim() || 'Your club'}</span><i style={{ background: newBranding.secondary }} /><i style={{ background: newBranding.highlight }} /></div>
          <div className="modal-actions"><button type="button" className="button-outline" onClick={() => setShowCreate(false)}>Cancel</button><button type="submit" className="button-primary">Create & customise ↗</button></div>
        </form>
      </div>}
    </div>
  );
}
