export type Role = 'owner' | 'administrator' | 'head_of_sport' | 'coach' | 'participant';
export type Action = 'manage_organization' | 'manage_permissions' | 'manage_scoring' | 'assign_coaches' | 'manage_attendance' | 'confirm_attendance' | 'view_squad' | 'view_own_profile' | 'self_check_in';

export interface RoleAssignment {
  userId: string;
  organizationId: string;
  role: Role;
  sportId?: string;
  squadId?: string;
  active: boolean;
}

export interface ResourceContext {
  organizationId: string;
  sportId?: string;
  squadId?: string;
  participantUserId?: string;
}

export type PermissionScope = Pick<ResourceContext, 'organizationId' | 'sportId' | 'squadId'>;
export type DelegableAction = 'manage_scoring' | 'manage_attendance' | 'confirm_attendance' | 'view_squad' | 'manage_permissions';
export type PermissionChoice = 'inherit' | 'allow' | 'deny';

export const EDITABLE_PERMISSION_ACTIONS: ReadonlyArray<{ action: DelegableAction; label: string; detail: string }> = [
  { action: 'manage_scoring', label: 'Manage scoring', detail: 'Edit scoring rules inside the assigned scope' },
  { action: 'manage_attendance', label: 'Record attendance', detail: 'Mark or correct an assigned squad’s register' },
  { action: 'confirm_attendance', label: 'Confirm sessions', detail: 'Approve a fully marked attendance register' },
  { action: 'view_squad', label: 'View squad', detail: 'Read information for an assigned squad' },
  { action: 'manage_permissions', label: 'Delegate permissions', detail: 'Sport-head or administrator authority to manage lower roles' },
];

const DELEGABLE = new Set<Action>(EDITABLE_PERMISSION_ACTIONS.map(entry => entry.action));
const ROLE_RANK: Record<Role, number> = { owner: 5, administrator: 4, head_of_sport: 3, coach: 2, participant: 1 };

export interface PermissionOverride {
  id: string;
  userId: string;
  scope: PermissionScope;
  action: DelegableAction;
  effect: 'allow' | 'deny';
  changedBy: string;
  changedAt: string;
}

export interface PermissionEvent {
  id: string;
  actorId: string;
  subjectId: string;
  scope: PermissionScope;
  action: DelegableAction;
  previous: PermissionChoice;
  next: PermissionChoice;
  reason: string;
  timestamp: string;
}

function assignmentCovers(assignment: RoleAssignment, target: ResourceContext): boolean {
  if (!assignment.active || assignment.organizationId !== target.organizationId) return false;
  if (assignment.role === 'owner' || assignment.role === 'administrator') return true;
  if (assignment.role === 'head_of_sport') return !!assignment.sportId && assignment.sportId === target.sportId;
  if (assignment.role === 'coach') {
    return !!assignment.squadId && !!assignment.sportId && assignment.sportId === target.sportId && assignment.squadId === target.squadId;
  }
  return assignment.role === 'participant';
}

function roleAllows(role: Role, action: Action): boolean {
  if (role === 'owner' || role === 'administrator') return true;
  if (role === 'head_of_sport') return ['manage_scoring', 'assign_coaches', 'manage_attendance', 'confirm_attendance', 'view_squad'].includes(action);
  if (role === 'coach') return ['manage_attendance', 'confirm_attendance', 'view_squad'].includes(action);
  return false;
}

function scopeApplies(scope: PermissionScope, target: ResourceContext): boolean {
  return scope.organizationId === target.organizationId &&
    (!scope.sportId || scope.sportId === target.sportId) &&
    (!scope.squadId || scope.squadId === target.squadId);
}

function sameScope(left: PermissionScope, right: PermissionScope): boolean {
  return left.organizationId === right.organizationId && left.sportId === right.sportId && left.squadId === right.squadId;
}

/** Shared domain decision only. Production must reproduce this in database/RPC policy. */
export function canPerform(assignments: RoleAssignment[], actorId: string, action: Action, target: ResourceContext, overrides: PermissionOverride[] = []): boolean {
  const active = assignments.filter(assignment => assignment.userId === actorId && assignmentCovers(assignment, target));
  if (!active.length) return false;

  // Personal actions are never delegable, even by an owner.
  if (action === 'self_check_in' || action === 'view_own_profile') return target.participantUserId === actorId;
  if (active.some(assignment => assignment.role === 'owner')) return true;

  // One person can have several scoped roles. A matching explicit decision has
  // precedence over role defaults; at the same specificity, denial wins.
  if (DELEGABLE.has(action)) {
    const matching = overrides.filter(override => override.userId === actorId && override.action === action && scopeApplies(override.scope, target));
    const specificity = (scope: PermissionScope) => Number(!!scope.sportId) + Number(!!scope.squadId);
    const decision = matching.reduce<PermissionOverride | undefined>((best, candidate) => {
      if (!best || specificity(candidate.scope) > specificity(best.scope) ||
        (specificity(candidate.scope) === specificity(best.scope) && candidate.effect === 'deny')) return candidate;
      return best;
    }, undefined);
    if (decision) {
      if (decision.effect === 'deny') return false;
      if (!active.some(assignment => assignment.role === 'administrator' || assignment.role === 'head_of_sport' || assignment.role === 'coach')) return false;
      // A coach must never receive the ability to manage other people's permissions.
      if (action === 'manage_permissions' && !active.some(assignment => ['administrator', 'head_of_sport'].includes(assignment.role))) return false;
      return true;
    }
  }
  return active.some(assignment => roleAllows(assignment.role, action));
}

export function permissionChoice(overrides: PermissionOverride[], userId: string, action: DelegableAction, scope: PermissionScope): PermissionChoice {
  return overrides.find(override => override.userId === userId && override.action === action && sameScope(override.scope, scope))?.effect ?? 'inherit';
}

/** Editors must outrank a subject in the exact organisation/sport/squad involved. */
export function canEditPermission(assignments: RoleAssignment[], overrides: PermissionOverride[], actorId: string, subjectId: string, action: DelegableAction, scope: PermissionScope): boolean {
  if (actorId === subjectId || !DELEGABLE.has(action)) return false;
  if (scope.squadId && !scope.sportId) return false;
  const actorRoles = assignments.filter(assignment => assignment.userId === actorId && assignmentCovers(assignment, scope));
  const subjectRoles = assignments.filter(assignment => assignment.userId === subjectId && assignmentCovers(assignment, scope));
  if (!actorRoles.length || !subjectRoles.length) return false;
  const actorRank = Math.max(...actorRoles.map(assignment => ROLE_RANK[assignment.role]));
  const subjectRank = Math.max(...subjectRoles.map(assignment => ROLE_RANK[assignment.role]));
  if (actorRank < ROLE_RANK.head_of_sport || actorRank <= subjectRank) return false;
  if (actorRank === ROLE_RANK.head_of_sport && subjectRank !== ROLE_RANK.coach) return false;
  if (action === 'manage_permissions' && subjectRank !== ROLE_RANK.head_of_sport && subjectRank !== ROLE_RANK.administrator) return false;
  // No one may delegate an action that their own higher role has been denied.
  return canPerform(assignments, actorId, 'manage_permissions', scope, overrides) &&
    canPerform(assignments, actorId, action, scope, overrides);
}

export interface PermissionChangeInput {
  actorId: string;
  subjectId: string;
  scope: PermissionScope;
  action: DelegableAction;
  next: PermissionChoice;
  reason: string;
  mutationId: string;
  timestamp: string;
}

/** Immutable, audited local simulation; do not connect this writer directly to real user tables. */
export function changePermission(assignments: RoleAssignment[], overrides: PermissionOverride[], events: PermissionEvent[], change: PermissionChangeInput): { overrides: PermissionOverride[]; events: PermissionEvent[] } {
  if (!canEditPermission(assignments, overrides, change.actorId, change.subjectId, change.action, change.scope)) {
    throw new Error('This role cannot change that person’s permission in this scope.');
  }
  if (!['inherit', 'allow', 'deny'].includes(change.next)) throw new Error('Invalid permission choice.');
  if (!change.reason || change.reason.trim().length < 3) throw new Error('Enter a reason of at least three characters.');
  if (!change.mutationId || Number.isNaN(Date.parse(change.timestamp))) throw new Error('A valid mutation ID and timestamp are required.');
  if (events.some(event => event.id === change.mutationId)) return { overrides, events };
  const previous = permissionChoice(overrides, change.subjectId, change.action, change.scope);
  if (previous === change.next) throw new Error('The selected permission is already in effect.');
  const remainder = overrides.filter(override => !(override.userId === change.subjectId && override.action === change.action && sameScope(override.scope, change.scope)));
  const updated = change.next === 'inherit' ? remainder : [...remainder, {
    id: change.mutationId, userId: change.subjectId, scope: { ...change.scope }, action: change.action,
    effect: change.next, changedBy: change.actorId, changedAt: change.timestamp,
  }];
  return {
    overrides: updated,
    events: [...events, { id: change.mutationId, actorId: change.actorId, subjectId: change.subjectId,
      scope: { ...change.scope }, action: change.action, previous, next: change.next,
      reason: change.reason.trim(), timestamp: change.timestamp }],
  };
}
