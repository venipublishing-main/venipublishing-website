/** Stable test definitions belong to the platform. Published rule revisions belong to organisations. */
export type BoundaryConvention = 'lower-inclusive' | 'upper-inclusive';
export type TestDirection = 'higher' | 'lower';

export interface TestDefinition {
  id: string;
  /** Platform-wide test-method revision, independent of each organisation's scoring rule. */
  revision: number;
  name: string;
  unit: string;
  direction: TestDirection;
  boundaryConvention: BoundaryConvention;
  minimumValue?: number;
}

export interface RuleScope {
  organizationId: string;
  sportId?: string;
  divisionId?: string;
}

export interface ScoringRule {
  id: string;
  testId: string;
  scope: RuleScope;
  revision: number;
  publishedAt: string;
  /** Ascending cutoffs create cutoffs.length + 1 scoring bands. */
  cutoffs: number[];
  labels: string[];
  scores: number[];
  /** Importance of this test in a weighted summary; zero excludes it. */
  weight: number;
}

export interface ScoringContext {
  organizationId: string;
  testId: string;
  sportId?: string;
  divisionId?: string;
  asOf?: string;
}

export interface ScoredResult {
  rawValue: number;
  unit: string;
  definitionRevision: number;
  bandIndex: number;
  label: string;
  score: number;
  weight: number;
  ruleId: string;
  ruleRevision: number;
}

export function validateScoringRule(rule: ScoringRule): void {
  if (!rule.id || !rule.testId || !rule.scope.organizationId) {
    throw new Error('A rule requires an ID, test ID and organisation ID.');
  }
  if (!Number.isInteger(rule.revision) || rule.revision < 1) {
    throw new Error('Rule revision must be a positive integer.');
  }
  if (Number.isNaN(Date.parse(rule.publishedAt))) {
    throw new Error('Rule publication time is invalid.');
  }
  if (rule.scope.divisionId && !rule.scope.sportId) {
    throw new Error('A division rule must identify its sport.');
  }
  if (rule.labels.length !== rule.cutoffs.length + 1 || rule.scores.length !== rule.labels.length) {
    throw new Error('Each scoring interval needs a label and numeric score.');
  }
  if (rule.labels.some(label => !label.trim()) || rule.scores.some(score => !Number.isFinite(score))) {
    throw new Error('Scoring labels and scores must be valid.');
  }
  if (!Number.isFinite(rule.weight) || rule.weight < 0) {
    throw new Error('Weight must be a non-negative finite number.');
  }
  for (let index = 0; index < rule.cutoffs.length; index += 1) {
    const value = rule.cutoffs[index];
    if (!Number.isFinite(value) || (index > 0 && value <= rule.cutoffs[index - 1])) {
      throw new Error('Scoring cutoffs must be finite and strictly ascending.');
    }
  }
}

function scopeSpecificity(rule: ScoringRule, context: ScoringContext): number {
  if (rule.scope.organizationId !== context.organizationId || rule.testId !== context.testId) return -1;
  if (rule.scope.sportId && rule.scope.sportId !== context.sportId) return -1;
  if (rule.scope.divisionId && rule.scope.divisionId !== context.divisionId) return -1;
  return rule.scope.divisionId ? 3 : rule.scope.sportId ? 2 : 1;
}

/** Division-specific settings take priority over sport settings, which take priority over organisation defaults. */
export function resolveScoringRule(rules: ScoringRule[], context: ScoringContext): ScoringRule | null {
  const asOf = Date.parse(context.asOf ?? new Date().toISOString());
  if (Number.isNaN(asOf)) throw new Error('The assessment date is invalid.');
  const matches = rules.filter(rule => {
    validateScoringRule(rule);
    return scopeSpecificity(rule, context) > 0 && Date.parse(rule.publishedAt) <= asOf;
  });
  matches.sort((a, b) =>
    scopeSpecificity(b, context) - scopeSpecificity(a, context) ||
    Date.parse(b.publishedAt) - Date.parse(a.publishedAt) ||
    b.revision - a.revision,
  );
  return matches[0] ?? null;
}

/** The exact published rule ID/revision is returned so a stored result retains its historical meaning. */
export function scoreMeasurement(definition: TestDefinition, rule: ScoringRule, rawValue: number): ScoredResult {
  validateScoringRule(rule);
  if (definition.id !== rule.testId) throw new Error('Test definition and scoring rule do not match.');
  if (!Number.isInteger(definition.revision) || definition.revision < 1) throw new Error('Test definition requires a valid revision.');
  if (!Number.isFinite(rawValue)) throw new Error('A completed measurement must be a finite number.');
  if (definition.minimumValue !== undefined && rawValue < definition.minimumValue) {
    throw new Error('Measurement is below the allowed minimum.');
  }
  const bandIndex = rule.cutoffs.reduce((count, cutoff) => {
    const crossed = definition.boundaryConvention === 'lower-inclusive' ? rawValue >= cutoff : rawValue > cutoff;
    return count + Number(crossed);
  }, 0);
  return {
    rawValue,
    unit: definition.unit,
    definitionRevision: definition.revision,
    bandIndex,
    label: rule.labels[bandIndex],
    score: rule.scores[bandIndex],
    weight: rule.weight,
    ruleId: rule.id,
    ruleRevision: rule.revision,
  };
}

/** Calculate a relative-strength measurement from contemporaneous kilograms. */
export function strengthRatio(loadKg: number, bodyWeightKg: number): number {
  if (!Number.isFinite(loadKg) || loadKg < 0 || !Number.isFinite(bodyWeightKg) || bodyWeightKg <= 0) {
    throw new Error('Load must be non-negative and bodyweight must be positive.');
  }
  return loadKg / bodyWeightKg;
}

/** Example aggregation method; final PBHS summary parity will be defined during report migration. */
export function weightedMean(results: Array<ScoredResult | null>, requireAll = false): number | null {
  if (requireAll && results.some(result => result === null)) return null;
  let numerator = 0;
  let denominator = 0;
  for (const result of results) {
    if (!result || result.weight === 0) continue;
    numerator += result.score * result.weight;
    denominator += result.weight;
  }
  return denominator > 0 ? numerator / denominator : null;
}

/** Create a new immutable revision. Consumers retain previous revisions for history. */
export function publishRuleRevision(previous: ScoringRule, draft: Pick<ScoringRule, 'cutoffs' | 'labels' | 'scores' | 'weight'>, publishedAt: string, id: string): ScoringRule {
  const next: ScoringRule = {
    ...previous,
    id,
    revision: previous.revision + 1,
    publishedAt,
    cutoffs: [...draft.cutoffs],
    labels: [...draft.labels],
    scores: [...draft.scores],
    weight: draft.weight,
  };
  validateScoringRule(next);
  if (Date.parse(next.publishedAt) <= Date.parse(previous.publishedAt)) {
    throw new Error('A new rule revision must be published after its predecessor.');
  }
  return next;
}
