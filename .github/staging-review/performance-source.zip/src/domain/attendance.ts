import { canPerform, type PermissionOverride, type RoleAssignment } from './permissions';

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused';
export type AttendanceSource = 'participant_check_in' | 'coach_entry' | 'coach_correction';

export interface AttendanceEntry {
  participantId: string;
  status: AttendanceStatus;
  source: AttendanceSource;
  changedBy: string;
  changedAt: string;
}

export interface AttendanceEvent {
  mutationId: string;
  kind: 'entry_changed' | 'session_confirmed';
  actorId: string;
  timestamp: string;
  participantId?: string;
  oldStatus?: AttendanceStatus;
  newStatus?: AttendanceStatus;
  note?: string;
}

export interface AttendanceSession {
  id: string;
  organizationId: string;
  sportId: string;
  squadId: string;
  scheduledAt: string;
  roster: string[];
  state: 'open' | 'confirmed';
  entries: Record<string, AttendanceEntry>;
  events: AttendanceEvent[];
  confirmedBy?: string;
  confirmedAt?: string;
  amendedAt?: string;
}

function assertTimestamp(timestamp: string): void {
  if (Number.isNaN(Date.parse(timestamp))) throw new Error('Invalid event timestamp.');
}

function isReplay(session: AttendanceSession, mutationId: string): boolean {
  return session.events.some(event => event.mutationId === mutationId);
}

export function createAttendanceSession(input: Pick<AttendanceSession, 'id' | 'organizationId' | 'sportId' | 'squadId' | 'scheduledAt' | 'roster'>): AttendanceSession {
  assertTimestamp(input.scheduledAt);
  if (new Set(input.roster).size !== input.roster.length) throw new Error('Roster contains duplicate participants.');
  return { ...input, roster: [...input.roster], state: 'open', entries: {}, events: [] };
}

export interface AttendanceChange {
  actorId: string;
  participantId: string;
  status: AttendanceStatus;
  source: AttendanceSource;
  mutationId: string;
  timestamp: string;
  note?: string;
}

/** Every participant check-in remains provisional until a coach confirms the entire session. */
export function recordAttendance(session: AttendanceSession, assignments: RoleAssignment[], change: AttendanceChange, overrides: PermissionOverride[] = []): AttendanceSession {
  assertTimestamp(change.timestamp);
  if (!change.mutationId) throw new Error('A mutation ID is required for safe retries.');
  if (isReplay(session, change.mutationId)) return session;
  if (!session.roster.includes(change.participantId)) throw new Error('Participant is not on the session roster.');
  const target = { organizationId: session.organizationId, sportId: session.sportId, squadId: session.squadId, participantUserId: change.participantId };
  if (change.source === 'participant_check_in') {
    if (change.status !== 'present' || session.state !== 'open') throw new Error('Participant check-in can only record presence in an open session.');
    if (!canPerform(assignments, change.actorId, 'self_check_in', target, overrides)) throw new Error('Participant cannot check in for this session.');
  } else {
    if (!canPerform(assignments, change.actorId, 'manage_attendance', target, overrides)) throw new Error('Coach lacks authority for this squad.');
    if (session.state === 'open' && change.source !== 'coach_entry') throw new Error('Use a coach entry before confirmation.');
    if (session.state === 'confirmed' && change.source !== 'coach_correction') throw new Error('Use an audited coach correction after confirmation.');
    if (session.state === 'confirmed' && (!change.note || !change.note.trim())) throw new Error('A post-confirmation correction requires a reason.');
  }
  const previous = session.entries[change.participantId];
  return {
    ...session,
    entries: {
      ...session.entries,
      [change.participantId]: {
        participantId: change.participantId,
        status: change.status,
        source: change.source,
        changedBy: change.actorId,
        changedAt: change.timestamp,
      },
    },
    amendedAt: session.state === 'confirmed' ? change.timestamp : session.amendedAt,
    events: [...session.events, {
      mutationId: change.mutationId,
      kind: 'entry_changed',
      actorId: change.actorId,
      timestamp: change.timestamp,
      participantId: change.participantId,
      oldStatus: previous?.status,
      newStatus: change.status,
      note: change.note,
    }],
  };
}

export function confirmAttendance(session: AttendanceSession, assignments: RoleAssignment[], actorId: string, mutationId: string, timestamp: string, overrides: PermissionOverride[] = []): AttendanceSession {
  assertTimestamp(timestamp);
  if (!mutationId) throw new Error('A mutation ID is required for safe retries.');
  if (isReplay(session, mutationId)) return session;
  if (session.state === 'confirmed') throw new Error('Session is already confirmed.');
  if (!canPerform(assignments, actorId, 'confirm_attendance', session, overrides)) throw new Error('Coach lacks authority to confirm this session.');
  const unmarked = session.roster.filter(participantId => !session.entries[participantId]);
  if (unmarked.length) throw new Error(`${unmarked.length} participant(s) still need an attendance status.`);
  return {
    ...session,
    state: 'confirmed',
    confirmedBy: actorId,
    confirmedAt: timestamp,
    events: [...session.events, { mutationId, kind: 'session_confirmed', actorId, timestamp }],
  };
}
