/** Organisation-owned appearance. No colours or badge files belong to the shared test engine. */
export interface OrganizationBranding {
  primary: string;
  secondary: string;
  highlight: string;
  /** Browser-local, resized preview only. Production must store an organisation-scoped asset reference. */
  badgeDataUrl?: string;
}

export const PBHS_SAMPLE_BRANDING: OrganizationBranding = {
  primary: '#185e43',
  secondary: '#af263b',
  highlight: '#ffffff',
};

export const CLUB_SAMPLE_BRANDING: OrganizationBranding = {
  primary: '#194c69',
  secondary: '#ca7936',
  highlight: '#f5d9aa',
};

const HEX_COLOUR = /^#[0-9a-fA-F]{6}$/;
const SAFE_BADGE = /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/;
const MAX_STORED_BADGE_LENGTH = 750_000;

export function isHexColour(value: unknown): value is string {
  return typeof value === 'string' && HEX_COLOUR.test(value);
}

export function normaliseBranding(value: unknown, fallback: OrganizationBranding = CLUB_SAMPLE_BRANDING): OrganizationBranding {
  const proposed = value && typeof value === 'object' ? value as Partial<OrganizationBranding> : {};
  const candidate = proposed.badgeDataUrl;
  const badgeDataUrl = typeof candidate === 'string' && candidate.length <= MAX_STORED_BADGE_LENGTH && SAFE_BADGE.test(candidate)
    ? candidate : undefined;
  return {
    primary: isHexColour(proposed.primary) ? proposed.primary.toLowerCase() : fallback.primary,
    secondary: isHexColour(proposed.secondary) ? proposed.secondary.toLowerCase() : fallback.secondary,
    highlight: isHexColour(proposed.highlight) ? proposed.highlight.toLowerCase() : fallback.highlight,
    ...(badgeDataUrl ? { badgeDataUrl } : {}),
  };
}

function luminance(hex: string): number {
  const components = [1, 3, 5].map(position => parseInt(hex.slice(position, position + 2), 16) / 255);
  const linear = components.map(component => component <= 0.04045 ? component / 12.92 : ((component + 0.055) / 1.055) ** 2.4);
  return linear[0] * 0.2126 + linear[1] * 0.7152 + linear[2] * 0.0722;
}

function contrastRatio(a: string, b: string): number {
  const brighter = Math.max(luminance(a), luminance(b));
  const darker = Math.min(luminance(a), luminance(b));
  return (brighter + 0.05) / (darker + 0.05);
}

/** Choose readable text on a customer-defined solid colour. */
export function textOnColour(background: string): '#ffffff' | '#162b36' {
  if (!isHexColour(background)) throw new Error('The colour must be a six-digit hex value.');
  return contrastRatio(background, '#ffffff') >= contrastRatio(background, '#162b36') ? '#ffffff' : '#162b36';
}

/** Use a darker version of bright brand colours when showing brand-coloured type on white. */
export function brandInkOnWhite(hex: string): string {
  if (!isHexColour(hex)) throw new Error('The colour must be a six-digit hex value.');
  let rgb = [1, 3, 5].map(position => parseInt(hex.slice(position, position + 2), 16));
  for (let attempt = 0; attempt < 20; attempt += 1) {
    const current = `#${rgb.map(value => Math.round(value).toString(16).padStart(2, '0')).join('')}`;
    if (contrastRatio(current, '#ffffff') >= 4.5) return current;
    rgb = rgb.map(value => value * 0.88);
  }
  return '#162b36';
}

export function validateBadgeFile(file: Pick<File, 'type' | 'size'>): void {
  if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
    throw new Error('Please upload a PNG, JPG or WebP badge. SVG files are not accepted.');
  }
  if (file.size <= 0 || file.size > 5 * 1024 * 1024) {
    throw new Error('Please choose a badge under 5 MB.');
  }
}

/** Resize on-device; the original image never leaves the browser in this prototype. */
export async function prepareBadgePreview(file: File): Promise<string> {
  validateBadgeFile(file);
  const objectUrl = URL.createObjectURL(file);
  try {
    const image = new Image();
    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve();
      image.onerror = () => reject(new Error('Unable to open this image.'));
      image.src = objectUrl;
    });
    if (!image.naturalWidth || !image.naturalHeight) throw new Error('The badge image is empty.');
    const scale = Math.min(1, 480 / Math.max(image.naturalWidth, image.naturalHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Image resizing is unavailable in this browser.');
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    const resized = canvas.toDataURL('image/webp', 0.83);
    const safe = normaliseBranding({ badgeDataUrl: resized });
    if (!safe.badgeDataUrl) throw new Error('The resized badge is too large for this preview.');
    return safe.badgeDataUrl;
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}
