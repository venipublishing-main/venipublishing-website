-- Account release step after both Performance migration transactions; execute only under a future GO.
begin;
do $gate$
declare reserve_id constant uuid := '708f2b73-1c2c-4565-bf94-4325c4af0d31';
begin
  if (select count(*) from auth.oauth_clients where deleted_at is null)<>1
    or not exists (select from auth.oauth_clients where id=reserve_id and deleted_at is null
      and client_type='confidential' and token_endpoint_auth_method='client_secret_basic'
      and redirect_uris='https://vf-reserve-stg.veni-reserve.workers.dev/auth/veni/callback') then
    raise exception 'Unexpected client inventory; obtain a new classification review';
  end if;
  insert into veni_account_routing.oauth_clients values (reserve_id,'authenticated') on conflict do nothing;
  if not exists(select from veni_account_routing.oauth_clients where client_id=reserve_id and token_role='authenticated')
    or exists(select from performance_internal.oauth_clients) then raise exception 'Wrong product registration'; end if;
end;
$gate$;
commit;
