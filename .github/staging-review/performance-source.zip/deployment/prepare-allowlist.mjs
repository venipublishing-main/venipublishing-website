// Print the exact reviewed Website registration fragment for the approved staging client.
import assert from 'node:assert/strict';
const id=process.argv[2];
assert.match(id??'',/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i,'Expected the registered Performance staging UUID');
assert.notEqual(id.toLowerCase(),'708f2b73-1c2c-4565-bf94-4325c4af0d31','Reserve client ID cannot be reused');
console.log(JSON.stringify({app:'performance-staging',clientId:id,label:'Veni Performance staging',
  redirectUris:['https://vf-performance-stg.veni-reserve.workers.dev/auth/veni/callback'],allowedScopes:['email']},null,2));
