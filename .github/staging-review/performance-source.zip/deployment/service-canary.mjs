// Server-side operator canary. Records outcomes only. No credentials are written to disk.
import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';

const primary='https://droslqfcazwkwvqlbtsq.supabase.co';
const reserve='708f2b73-1c2c-4565-bf94-4325c4af0d31';
const uuid=/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
function check(condition, message) { if (!condition) throw Error(message); }
function sameIds(actual, expected, label) {
  check(Array.isArray(expected) && expected.every(id=>uuid.test(id)),label+' fixture ID list missing');
  check(Array.isArray(actual) && actual.every(row=>uuid.test(row.id)),label+' unexpected response');
  check(JSON.stringify(actual.map(row=>row.id).sort())===JSON.stringify([...expected].sort()),label+' fixture set mismatch');
}
export async function sessionCanary({provider,app,key,access,refresh,secret,fixture,rotate=false}) {
  check([primary,'http://127.0.0.1:57421'].includes(provider),'Unexpected issuer');
  check(['website','reserve','performance'].includes(app),'Unknown app');
  check(uuid.test(fixture.user) && /^[^@\s]+@example\.invalid$/i.test(fixture.email),'Synthetic identity required');
  const client=app==='website'?null:fixture.client;
  if (app!=='website') check(uuid.test(client),'Fixture client missing');
  if (provider===primary && app!=='website') check((app==='reserve')===(client===reserve),'Client classification mismatch');
  async function call(path,token,options={}) {
    return fetch(provider+path,{...options,redirect:'error',signal:AbortSignal.timeout(10000),
      headers:{apikey:key,...(token?{Authorization:'Bearer '+token}:{}),...options.headers}});
  }
  async function verify(token) {
    const user=await call('/auth/v1/user',token);
    check(user.ok,'Auth user check failed');
    const identity=await user.json();
    check(identity.id===fixture.user && identity.email===fixture.email,'Token does not belong to the nominated synthetic account');
    const claim=JSON.parse(Buffer.from(token.split('.')[1],'base64url'));
    check(claim.iss===provider+'/auth/v1' && claim.sub===identity.id && (claim.client_id??null)===client &&
      claim.role===(app==='performance'?'performance_api':'authenticated') && uuid.test(claim.session_id),'Unexpected token classification');
  }
  await verify(access);
  if (rotate) {
    check(typeof refresh==='string' && refresh.length>0,'Matching synthetic refresh token required');
    let response;
    if (client) {
      check(typeof secret==='string' && secret.length>0,'Confidential server-side client binding required');
      response=await call('/auth/v1/oauth/token',null,{method:'POST',headers:{Authorization:'Basic '+Buffer.from(client+':'+secret).toString('base64')},
        body:new URLSearchParams({grant_type:'refresh_token',refresh_token:refresh})});
    } else {
      response=await call('/auth/v1/token?grant_type=refresh_token',null,{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({refresh_token:refresh})});
    }
    check(response.ok,'Provider refresh failed');
    access=(await response.json()).access_token;
    await verify(access);
  }
  if (app==='website') {
    const profile=await call('/rest/v1/profiles?select=id',access);
    check(profile.ok,'Profile read failed');sameIds(await profile.json(),[fixture.user],'Website');
    const readings=await call('/rest/v1/arcana_readings?select=id',access);
    check(readings.ok,'Arcana read failed');sameIds(await readings.json(),fixture.readings,'Arcana');
  } else {
    const path=app==='reserve'?'reserve_list_setup_tenants':'performance_workspace';
    const resp=await call('/rest/v1/rpc/'+path,access,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
    if (app==='performance' && fixture.entitled===false) check([401,403].includes(resp.status),'Unentitled workspace allowed');
    else {
      check(resp.ok,app+' workspace failed');
      const data=await resp.json();
      if(app==='performance') check(data.user_id===fixture.user,'Workspace identity differs');
      sameIds(app==='reserve'?data:data.organizations,fixture.organizations,app);
    }
  }
  return 'PASS '+app+' synthetic identity, token role and expected resource set'+(rotate?' after provider refresh':'');
}
async function surfaces(phase) {
  const specs=[['https://venipublishing.co.za/account/settings/',200],['https://vf-reserve-stg.veni-reserve.workers.dev/health',200],
    ['https://vf-reserve-stg.veni-reserve.workers.dev/ready',200],['https://vf-reserve-stg.veni-reserve.workers.dev/api/workspace/session',401]];
  if(phase==='after')specs.push(['https://vf-performance-stg.veni-reserve.workers.dev/owner',200],
    ['https://vf-performance-stg.veni-reserve.workers.dev/api/workspace',401]);
  for(const [url,expected] of specs) {
    const r=await fetch(url,{redirect:'error',signal:AbortSignal.timeout(12000)});check(r.status===expected,'HTTP canary failed '+url);
    if(url.endsWith('/ready'))check((await r.json()).dependencies?.supabase==='ok','Reserve database not ready');
    if(url.endsWith('/owner'))check(r.headers.get('content-type')?.includes('text/html'),'Missing Performance frontend');
    console.log('PASS',expected,url);
  }
}
if(process.argv[1] && import.meta.url===pathToFileURL(resolve(process.argv[1])).href) {
  try {
    const [mode,arg,file,...flags]=process.argv.slice(2);
    if(mode==='surface' && ['before','after'].includes(arg))await surfaces(arg);
    else if(mode==='session' && flags.includes('--approved-synthetic')) {
      const fixture=JSON.parse(readFileSync(file,'utf8'));
      const env=process.env;
      console.log(await sessionCanary({provider:primary,app:arg,key:env.QA_PUBLISHABLE_KEY,access:env.QA_ACCESS_TOKEN,
        refresh:env.QA_REFRESH_TOKEN,secret:env.QA_CLIENT_SECRET,fixture,rotate:flags.includes('--refresh')}));
    } else throw Error('Use surface before|after, or session website|reserve|performance fixture.json --approved-synthetic [--refresh]');
  } catch(e) { console.error('FAIL',e instanceof SyntaxError?'Invalid fixture or token data':e.message);process.exitCode=1; }
}
