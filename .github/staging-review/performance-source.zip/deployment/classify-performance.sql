-- psql -v ON_ERROR_STOP=1 -v performance_client=<approved-public-UUID> -f <file>
-- Execute only after the hook is active and shared product canaries have passed.
begin;
select set_config('veni.release_performance_id',(:'performance_client')::uuid::text,true);
do $gate$
declare
  pilot constant uuid := current_setting('veni.release_performance_id')::uuid;
  reserve_id constant uuid := '708f2b73-1c2c-4565-bf94-4325c4af0d31';
begin
  if pilot=reserve_id or
    not exists(select from auth.oauth_clients where id=pilot and deleted_at is null and client_type='confidential'
      and token_endpoint_auth_method='client_secret_basic'
      and redirect_uris='https://vf-performance-stg.veni-reserve.workers.dev/auth/veni/callback')
    or not exists(select from auth.oauth_clients where id=reserve_id and deleted_at is null
      and redirect_uris='https://vf-reserve-stg.veni-reserve.workers.dev/auth/veni/callback')
    or exists(select from auth.oauth_clients where deleted_at is null and id not in (pilot,reserve_id))
    or not exists(select from veni_account_routing.oauth_clients where client_id=reserve_id and token_role='authenticated')
    or exists(select from performance_internal.oauth_clients where id<>pilot)
  then raise exception 'Staging client or callback differs from reviewed inventory'; end if;
  insert into veni_account_routing.oauth_clients values (pilot,'performance_api') on conflict do nothing;
  if not exists(select from veni_account_routing.oauth_clients where client_id=pilot and token_role='performance_api')
    then raise exception 'Wrong Performance route'; end if;
  insert into performance_internal.oauth_clients values (pilot) on conflict do nothing;
end;
$gate$;
commit;
