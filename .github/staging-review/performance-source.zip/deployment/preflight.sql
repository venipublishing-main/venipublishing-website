-- Read-only baseline for the specific primary staging release. Never query credential columns.
begin read only;
select current_timestamp as observed_at, current_setting('server_version') as postgres;
select id,client_type,redirect_uris,token_endpoint_auth_method
  from auth.oauth_clients where deleted_at is null order by id;
select version,name from supabase_migrations.schema_migrations order by version;
do $check$
begin
  if to_regnamespace('performance') is not null or to_regnamespace('performance_internal') is not null
    or to_regnamespace('veni_account_routing') is not null or to_regrole('performance_api') is not null
    or exists(select from pg_proc where pronamespace='public'::regnamespace and left(proname,12)='performance_')
    or exists(select from public.products where slug='veni-performance')
    or (select count(*) from auth.oauth_clients where deleted_at is null)<>1
    or not exists(select from auth.oauth_clients where deleted_at is null
      and id='708f2b73-1c2c-4565-bf94-4325c4af0d31'
      and redirect_uris='https://vf-reserve-stg.veni-reserve.workers.dev/auth/veni/callback'
      and client_type='confidential' and token_endpoint_auth_method='client_secret_basic')
    or not has_table_privilege('supabase_auth_admin','auth.sessions','select')
    or not exists(select from pg_constraint where conrelid='public.products'::regclass
      and conname='products_platform_check' and pg_get_constraintdef(oid)=
      $value$CHECK ((platform = ANY (ARRAY['veni-kids'::text, 'ai-geopolitic'::text, 'veni-faithful'::text, 'veni-mythos'::text, 'veni-arcana'::text, 'buza'::text, 'veni-publishing'::text])))$value$)
  then raise exception 'Baseline drift: reconcile with Account Architecture before release'; end if;
end;
$check$;
select (select count(*) from auth.users) as identities,(select count(*) from auth.identities) as provider_links,
       (select count(*) from public.profiles) as profiles,(select count(*) from public.entitlements) as entitlements,
       (select count(*) from public.arcana_readings) as readings,(select count(*) from reserve.tenants) as reserve_tenants,
       (select count(*) from storage.buckets) as buckets,(select count(*) from storage.objects) as storage_objects;
rollback;
